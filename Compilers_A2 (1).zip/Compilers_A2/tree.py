class Tree:
    def __init__(self, value, children):
        
        self.value = value
        self.children = children



    
