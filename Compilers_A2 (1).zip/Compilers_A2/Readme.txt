PARSER FOR BOLT LANGUAGE

The type of parser we implemented is a Lalr(1) parser.
We have implemented error handling by panic mode error recovery.

***To run the programs***
Type -"python final.py"


Made by-
Rupsa Dhar
Mereddy Aishwwarya Reddi
Pranavi Marripudi
Adesh Kumar Pradhan