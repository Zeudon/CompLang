from parsing import *
from generator import *
import tree as tree
import csv
from anytree import Node, RenderTree
from anytree.exporter import DotExporter
import scanner

def readFile(input):
	file1 = open(input, 'r')
	code = file1.read()
	return code

def stateIndex(stack):
	return stack[2 * ((len(stack) - 1) >> 1)]

def panic_recovery(stack,tokens,index_input):
    while(1):
        if(stack[-2]=='stmnt'):
            break
        elif(stack[-2]=='{'):
            break
        else:
            stack.pop()
            stack.pop()
    while(index_input<len(tokens)):
        if(tokens[index_input]==';'):
            #print(tokens[index_input])
            #print(index_input)
            tokens.pop(index_input)
            break
        elif(tokens[index_input]=='}'):
            break
        else:
            tokens.pop(index_input)
    #print(tokens)
    #print(stack)
    return stack,tokens

            
def printTree(tree):
    result = tree.value
    if (0 < len(tree.children)):
        print(result)
        for i in tree.children[0]:
            print(printTree(i))
    return result


def main():
    stack=[]
    error_output=[]
    stack.append(0)
    finallex=scanner.driver()
    #print(finallex)
    tokens_input=[]
    for i in finallex:
        if(i[1]=="keyword"):
            #print(i)
            tokens_input.append(i[0])
        if(i[1]=="identifier"):
            tokens_input.append('id')
        if(i[1]=="Operator"):
            tokens_input.append(i[0])
        if(i[1]=="integerLiteral"):
            tokens_input.append('intType')
        if(i[1]=="character"):
            tokens_input.append('charType')
        if(i[1]=="floatingPointLiteral"):
            tokens_input.append('floatType')
    tokens_input.append('$end')
    #str1 = input("Enter input: ")
    #print(str1)
    #tokens=[]
    #tokens= str1.split(' ')
    tokens=tokens_input
    #print(tokens)
    tokenindex=0
    token=tokens[tokenindex]
    s_index=stateIndex(stack)
    #print(len(tokens))
    gr=get_grammar()
    stateid=0
    with open('parsing-table.csv','r') as csvDataFile:
        csvReader = csv.DictReader(csvDataFile)
        flag=1
        step=0
        index_input=0
        cnt=0
        ind=0
        parsetree=[]
        while(flag==1):
            cnt=0
            temp=""
            csvDataFile.seek(0)
            csvReader = csv.DictReader(csvDataFile)
            for row in csvReader:
                #print("entered")
                #print("hi"+str(cnt))
                #print("bye"+str(stateid))
                if(cnt==stateid):
                    #print("hello")
                    if(tokens[index_input]=="$end"):
                        temp=row[tokens[index_input]]
                    else:
                        temp=row["'"+tokens[index_input]+"'"]
                    #print(temp)
                    if(temp==''):
                        print("Error")
                        #print(finallex[index_input][3])
                        error_output.append("The Error is on line :"+str(finallex[index_input][3]))
                        stack,tokens=panic_recovery(stack,tokens,index_input)
                        stateid=int(stack[-1])
                    elif(temp[0]=='s'):
                        stack.append(tokens[index_input])
                        y=2
                        intermed=temp[1]
                        while(y<len(temp)):
                            intermed=intermed+temp[y]
                            y=y+1
                        stack.append(int(intermed))
                        print(stack)
                        stateid=int(intermed)
                        index_input=index_input+1
                    elif(temp[0]=='r'):
                        y=2
                        intermed=temp[1]
                        while(y<len(temp)):
                            intermed=intermed+temp[y]
                            y=y+1
                        #print(intermed)
                        replacement=gr.productions[int(intermed)][0]
                        times_pop=len(gr.productions[int(intermed)][1])
                        #print(replacement)
                        treeobj=tree.Tree(replacement,[])
                        childarr=[]
                        if(len(stack)>1):
                            while(times_pop!=0):
                                stack.pop()
                                childarr.append(stack[len(stack)-1])
                                stack.pop()
                                times_pop=times_pop-1
                        #print(childarr)
                        childarr.reverse()
                        #print(childarr)
                        """if(len(childarr)>0):
                            for k in childarr:
                                locals()[k] = Node("'"+k+"'",parent=replacement)
                        else:
                            locals()[replacement]=Node("'"+replacement+"'")"""
                        treeobj.children.append(childarr)
                        parsetree.append(treeobj)
                        ind=ind+1
                        gotorow=int(stack[-1])
                        #print(gotorow)
                        stack.append(replacement)
                        print(stack)
                        x=0
                        csvDataFile.seek(0)
                        csvReader1 = csv.DictReader(csvDataFile)
                        for row in csvReader1:
                            #print(row)
                            if(x==gotorow):
                                temp=row[replacement]
                                #print(temp)
                                stack.append(int(temp))
                                stateid=int(temp)
                                print(stack)
                                break
                            x=x+1
                    else:
                        flag=0
                    break
                cnt=cnt+1
        #print(len(parsetree))
        n=len(parsetree)-1
        #print(parsetree[n].value)
        #print(len(parsetree[n].children[0]))
        #program1 = Node("program1")
        globals()[parsetree[n].value]=Node("\""+parsetree[n].value+"\"")
        #print(program1)
        #for pre, fill, node in RenderTree(program1):
            #print("%s%s" % (pre, node.name))
        while(n>=0):
            if(len(parsetree[n].children[0])==0):
                #print(str(j.value))
                globals()[parsetree[n].value]=Node("\""+parsetree[n].value+"\"")
            else:
                #print(str(j.value)+'    '+str(j.children[0]))
                for k in parsetree[n].children[0]:
                    #print(parsetree[n].value)
                    #valstr=parsetree[n].value
                    #print(k)
                    globals()[k] = Node("\""+k+"\"",parent=globals()[parsetree[n].value])
            n=n-1

                
        #printTree(parsetree[1])
        for k in error_output:
            print(k)
        for pre, fill, node in RenderTree(program1):
            print("%s%s" % (pre, node.name))
            

if __name__ == "__main__":
    main()