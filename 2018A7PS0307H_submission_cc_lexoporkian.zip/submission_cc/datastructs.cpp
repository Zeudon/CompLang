#include "datastructs.h"

Symbol::Symbol(){
    val = 0;
    type = 0;
    s_val = "";
}
Symbol::Symbol(int v, int t, std::string s){
    val = v;
    type = t;
    s_val = s;
}

Symbol::Symbol(int v, int t, std::string s, int line_no){
    val = v;
    type = t;
    s_val = s;
    lineno = line_no;
}

Rule::Rule(Symbol nt){
    lhs = nt;
}

Symbol eof_c(30,T,"$");
Symbol emp(0,EMP,"epsilon");